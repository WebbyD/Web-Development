function myFunction() {
    alert("I'm from Baltimore, Maryland, later moved to Harford County when I was 2. Graduated from Kennedy Krieger High School on June 7th, 2013 then studied Computer Information Systems at Harford Community College. Started on September 2nd 2014, graduated May 24th 2018. GPA of 3.30 and I love web development!!");
}

function myFunction2(){
	alert("Also....HOORAY FOR WEB DEVELOPMENT!!!!!") 
}